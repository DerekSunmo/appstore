# Beets

A music library manager and not, for the most part, a music player. It does include a simple player plugin and an experimental Web-based player, but it generally leaves actual sound-reproduction to specialized tools.

---

**Homepage:** https://hub.docker.com/r/linuxserver/beets

**WebUI Port:** `8337`