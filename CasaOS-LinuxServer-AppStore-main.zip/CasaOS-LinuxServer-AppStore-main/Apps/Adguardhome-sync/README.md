# Adguardhome sync

A tool to synchronize AdGuardHome config to replica instances.

---

**Homepage:** https://hub.docker.com/r/linuxserver/adguardhome-sync

**WebUI Port:** `8080`