# Emby

Organizes video, music, live TV, and photos from personal media libraries and streams them to smart TVs, streaming boxes and mobile devices. This container is packaged as a standalone emby Media Server.

---

**Homepage:** https://hub.docker.com/r/linuxserver/emby

**WebUI Port:** `8096`