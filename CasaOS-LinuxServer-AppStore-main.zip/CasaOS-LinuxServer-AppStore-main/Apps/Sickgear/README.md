# Sickgear

Provides management of TV shows and/or Anime, it detects new episodes, links downloader apps, and more. . For more information on SickGear visit their website and check it out: https://github. Com/SickGear/SickGear

---

**Homepage:** https://hub.docker.com/r/linuxserver/sickgear

**WebUI Port:** `8081`