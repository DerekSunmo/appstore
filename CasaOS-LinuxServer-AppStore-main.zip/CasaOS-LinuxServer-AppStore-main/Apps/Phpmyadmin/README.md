# Phpmyadmin

A free software tool written in PHP, intended to handle the administration of MySQL over the Web. PhpMyAdmin supports a wide range of operations on MySQL and MariaDB.

---

**WebUI Port:** `80`