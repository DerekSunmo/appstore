# Calibre

A powerful and easy to use e-book manager. Users say it's outstanding and a must-have. It'll allow you to do nearly everything and it takes things a step beyond normal e-book software. It's also completely free and open source and great for both casual users and computer experts.

---

**Homepage:** https://hub.docker.com/r/linuxserver/calibre

**WebUI Port:** `8080`