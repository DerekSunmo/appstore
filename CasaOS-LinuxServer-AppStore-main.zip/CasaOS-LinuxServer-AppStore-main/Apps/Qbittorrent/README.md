# Qbittorrent

The Qbittorrent project aims to provide an open-source software alternative to µTorrent. QBittorrent is based on the Qt toolkit and libtorrent-rasterbar library.

---

**Homepage:** https://hub.docker.com/r/linuxserver/qbittorrent

**WebUI Port:** `8080`