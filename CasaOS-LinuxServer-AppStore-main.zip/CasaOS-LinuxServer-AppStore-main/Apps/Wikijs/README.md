# Wikijs

A modern, lightweight and powerful wiki app built on NodeJS.

---

**Homepage:** https://hub.docker.com/r/linuxserver/wikijs

**WebUI Port:** `3000`