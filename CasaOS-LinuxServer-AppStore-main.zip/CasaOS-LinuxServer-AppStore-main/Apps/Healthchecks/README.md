# Healthchecks

A watchdog for your cron jobs. It's a web server that listens for pings from your cron jobs, plus a web interface.

---

**WebUI Port:** `8000`