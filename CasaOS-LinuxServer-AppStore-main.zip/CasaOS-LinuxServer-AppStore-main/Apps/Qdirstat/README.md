# Qdirstat

Qt-based directory statistics: KDirStat without any KDE -- from the author of the original KDirStat.

---