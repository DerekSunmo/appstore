# Sqlitebrowser

A high quality, visual, open source tool to create, design, and edit database files compatible with SQLite.

---

**Homepage:** https://hub.docker.com/r/linuxserver/sqlitebrowser

**WebUI Port:** `3000`