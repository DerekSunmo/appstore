# Bazarr

A companion application to Sonarr and Radarr. It can manage and download subtitles based on your requirements. You define your preferences by TV show or movie and Bazarr takes care of everything for you.

---

**Homepage:** https://hub.docker.com/r/linuxserver/bazarr

**WebUI Port:** `6767`