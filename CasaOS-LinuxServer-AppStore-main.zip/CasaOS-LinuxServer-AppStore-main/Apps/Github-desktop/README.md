# Github desktop

An open source Electron-based GitHub app. It is written in TypeScript and uses React.

---