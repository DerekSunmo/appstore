# Diskover

An open source file system indexer that uses Elasticsearch to index and manage data across heterogeneous storage systems.

---

**Homepage:** https://hub.docker.com/r/linuxserver/diskover

**WebUI Port:** `80`