# Feed2toot

Automatically parses rss feeds, identifies new posts and posts them on the Mastodon social network.

---