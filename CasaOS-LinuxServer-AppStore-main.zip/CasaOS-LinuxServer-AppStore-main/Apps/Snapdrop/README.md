# Snapdrop

A local file sharing in your browser. Inspired by Apple's Airdrop.

---

**Homepage:** https://hub.docker.com/r/linuxserver/snapdrop

**WebUI Port:** `80`