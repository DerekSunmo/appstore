# Budge

An open source 'budgeting with envelopes' personal finance app.

---

**WebUI Port:** `80`