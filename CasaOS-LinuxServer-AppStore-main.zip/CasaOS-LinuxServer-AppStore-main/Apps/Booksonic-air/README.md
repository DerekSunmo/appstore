# Booksonic air

A platform for accessing the audiobooks you own wherever you are. At the moment the platform consists of: * Booksonic Air - A server for streaming your audiobooks, successor to the original Booksonic server and based on Airsonic. * Booksonic App - An DSub based Android app for connection to Booksonic-Air servers.

---

**Homepage:** https://hub.docker.com/r/linuxserver/booksonic-air

**WebUI Port:** `4040`