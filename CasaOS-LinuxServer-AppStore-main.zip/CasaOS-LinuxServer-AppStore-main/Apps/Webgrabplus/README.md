# Webgrabplus

A multi-site incremental xmltv epg grabber. It collects tv-program guide data from selected tvguide sites for your favourite channels.

---

**Homepage:** https://hub.docker.com/r/linuxserver/webgrabplus