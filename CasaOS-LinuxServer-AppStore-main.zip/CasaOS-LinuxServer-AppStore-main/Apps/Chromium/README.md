# Chromium

An open-source browser project that aims to build a safer, faster, and more stable way for all users to experience the web.

---