# Duplicati

Works with standard protocols like FTP, SSH, WebDAV as well as popular services like Microsoft OneDrive, Amazon Cloud Drive & S3, Google Drive, box. Com, Mega, hubiC and many others.

---

**Homepage:** https://hub.docker.com/r/linuxserver/duplicati

**WebUI Port:** `8200`