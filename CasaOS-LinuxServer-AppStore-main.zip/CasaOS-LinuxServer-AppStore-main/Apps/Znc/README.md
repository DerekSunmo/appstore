# Znc

An IRC network bouncer or BNC. It can detach the client from the actual IRC server, and also from selected channels. Multiple clients from different locations can connect to a single ZNC account simultaneously and therefore appear under the same nickname on IRC.

---

**Homepage:** https://hub.docker.com/r/linuxserver/znc