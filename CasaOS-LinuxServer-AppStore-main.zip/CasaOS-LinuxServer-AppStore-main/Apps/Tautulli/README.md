# Tautulli

A python based web application for monitoring, analytics and notifications for Plex Media Server.

---

**Homepage:** https://hub.docker.com/r/linuxserver/tautulli

**WebUI Port:** `8181`