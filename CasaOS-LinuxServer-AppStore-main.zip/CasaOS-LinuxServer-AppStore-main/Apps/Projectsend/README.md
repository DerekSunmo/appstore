# Projectsend

A self-hosted application that lets you upload files and assign them to specific clients that you create yourself. Secure, private and easy. No more depending on external services or e-mail to send those files.

---

**Homepage:** https://hub.docker.com/r/linuxserver/projectsend

**WebUI Port:** `80`