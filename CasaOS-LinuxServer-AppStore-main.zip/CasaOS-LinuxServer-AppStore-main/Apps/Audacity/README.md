# Audacity

An easy-to-use, multi-track audio editor and recorder. Developed by a group of volunteers as open source.

---

**Homepage:** https://hub.docker.com/r/linuxserver/audacity

**WebUI Port:** `3000`