# Pyload ng

A Free and Open Source download manager written in Python and designed to be extremely lightweight, easily extensible and fully manageable via web.

---

**WebUI Port:** `8000`