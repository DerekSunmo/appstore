# Htpcmanager

A front end for many htpc related applications.

---

**Homepage:** https://hub.docker.com/r/linuxserver/htpcmanager

**WebUI Port:** `8085`