# Netbox

An IP address management (IPAM) and data center infrastructure management (DCIM) tool. Initially conceived by the network engineering team at DigitalOcean, NetBox was developed specifically to address the needs of network and infrastructure engineers. It is intended to function as a domain-specific source of truth for network operations.

---

**Homepage:** https://hub.docker.com/r/linuxserver/netbox

**WebUI Port:** `8000`