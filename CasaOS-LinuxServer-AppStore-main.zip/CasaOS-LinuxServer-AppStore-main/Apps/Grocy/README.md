# Grocy

An ERP system for your kitchen. Cut down on food waste, and manage your chores with this brilliant utility. Keep track of your purchases, how much food you are wasting, what chores need doing and what batteries need charging with this proudly Open Source tool For more information on grocy visit their website and check it out: https://grocy. Info

---

**Homepage:** https://hub.docker.com/r/linuxserver/grocy

**WebUI Port:** `80`