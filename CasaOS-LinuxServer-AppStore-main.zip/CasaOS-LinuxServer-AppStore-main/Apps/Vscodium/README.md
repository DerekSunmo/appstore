# Vscodium

A community-driven, freely-licensed binary distribution of Microsoft’s editor VS Code.

---