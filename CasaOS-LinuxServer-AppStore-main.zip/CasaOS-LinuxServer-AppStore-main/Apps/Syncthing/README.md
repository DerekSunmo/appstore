# Syncthing

Replaces proprietary sync and cloud services with something open, trustworthy and decentralized. Your data is your data alone and you deserve to choose where it is stored, if it is shared with some third party and how it's transmitted over the Internet.

---

**Homepage:** https://hub.docker.com/r/linuxserver/syncthing

**WebUI Port:** `8384`