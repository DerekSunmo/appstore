# Nginx

A simple webserver with php support. The config files reside in /config for easy user customization.

---

**Homepage:** https://hub.docker.com/r/linuxserver/nginx

**WebUI Port:** `80`