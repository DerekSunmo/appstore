# Apprise api

Takes advantage of Apprise through your network with a user-friendly API. * Send notifications to more then 65+ services. * An incredibly lightweight gateway to Apprise. * A production ready micro-service at your disposal. Apprise API was designed to easily fit into existing (and new) eco-systems that are looking for a simple notification solution.

---

**Homepage:** https://hub.docker.com/r/linuxserver/apprise-api

**WebUI Port:** `8000`