# Minetest

(server) is a near-infinite-world block sandbox game and a game engine, inspired by InfiniMiner, Minecraft, and the like.

---

**Homepage:** https://hub.docker.com/r/linuxserver/minetest