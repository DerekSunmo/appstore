# Lollypop

A lightweight modern music player designed to work excellently on the GNOME desktop environment.

---