# Daapd

(iTunes) media server with support for AirPlay devices, Apple Remote (and compatibles), Chromecast, MPD and internet radio.

---

**Homepage:** https://hub.docker.com/r/linuxserver/daapd

**WebUI Port:** `3689`