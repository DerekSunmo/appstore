# Thelounge

(a fork of shoutIRC) is a web IRC client that you host on your own server.

---

**Homepage:** https://hub.docker.com/r/linuxserver/thelounge

**WebUI Port:** `9000`