# Unifi network-application

The Unifi-network-application software is a powerful, enterprise wireless software engine ideal for high-density client deployments requiring low latency and high uptime performance.

---

**WebUI Port:** `8080`