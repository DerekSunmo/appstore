# Piwigo

A photo gallery software for the web that comes with powerful features to publish and manage your collection of pictures.

---

**Homepage:** https://hub.docker.com/r/linuxserver/piwigo

**WebUI Port:** `80`