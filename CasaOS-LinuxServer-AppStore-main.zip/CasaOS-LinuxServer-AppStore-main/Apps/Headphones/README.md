# Headphones

An automated music downloader for NZB and Torrent, written in Python. It supports SABnzbd, NZBget, Transmission, µTorrent and Blackhole.

---

**Homepage:** https://hub.docker.com/r/linuxserver/headphones

**WebUI Port:** `8181`