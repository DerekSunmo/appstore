# Synclounge

A third party tool that allows you to watch Plex in sync with your friends/family, wherever you are.

---

**Homepage:** https://hub.docker.com/r/linuxserver/synclounge

**WebUI Port:** `8088`