# Lazylibrarian

A program to follow authors and grab metadata for all your digital reading needs. It uses a combination of Goodreads Librarything and optionally GoogleBooks as sources for author info and book info. This container is based on the DobyTang fork.

---

**Homepage:** https://hub.docker.com/r/linuxserver/lazylibrarian

**WebUI Port:** `5299`