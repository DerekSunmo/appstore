# Ngircd

A free, portable and lightweight Internet Relay Chat server for small or private networks, developed under the GNU General Public License (GPL). It is easy to configure, can cope with dynamic IP addresses, and supports IPv6, SSL-protected connections as well as PAM for authentication. It is written from scratch and not based on the original IRCd.

---

**Homepage:** https://hub.docker.com/r/linuxserver/ngircd

**WebUI Port:** `6667`