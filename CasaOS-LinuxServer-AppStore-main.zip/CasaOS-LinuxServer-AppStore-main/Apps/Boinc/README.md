# Boinc

A platform for high-throughput computing on a large scale (thousands or millions of computers). It can be used for volunteer computing (using consumer devices) or grid computing (using organizational resources). It supports virtualized, parallel, and GPU-based applications.

---

**Homepage:** https://hub.docker.com/r/linuxserver/boinc

**WebUI Port:** `8080`