# Lidarr

A music collection manager for Usenet and BitTorrent users. It can monitor multiple RSS feeds for new tracks from your favorite artists and will grab, sort and rename them. It can also be configured to automatically upgrade the quality of files already downloaded when a better quality format becomes available.

---

**Homepage:** https://hub.docker.com/r/linuxserver/lidarr

**WebUI Port:** `8686`